#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtWidgets>
#include <QGLWidget>
#include <MainPaintScene.h>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    scence =new MainPaintScene(ui->graphicsView);
    ui->graphicsView->setScene(scence);
    ui->graphicsView->centerOn(0,0);
    scence->addLine(0,0,100,100);
    ui->graphicsView->setViewport(new QGLWidget(QGLFormat(QGL::SampleBuffers)));
}



MainWindow::~MainWindow()
{
    delete ui;
}
