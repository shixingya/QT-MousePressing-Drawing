#ifndef MAINPAINTSCENE_H
#define MAINPAINTSCENE_H

#include <QtWidgets>


class MainPaintScene : public QGraphicsScene
{
    Q_OBJECT

public:
    explicit MainPaintScene(QObject *parent = 0);
    ~MainPaintScene();

private:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

    QPointF PrePos;
    QPointF CurrentPos;
    ulong lastTimer =0;
    ulong myTimer =0;

    short interval =5;
    QPen pen;
    QGraphicsEllipseItem *ellipseItem=nullptr;
private slots:
    void test();
};

#endif // MAINPAINTSCENE_H
