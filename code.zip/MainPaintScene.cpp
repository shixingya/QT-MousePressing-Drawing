#include "MainPaintScene.h"

const int _tWidth =20;
MainPaintScene::MainPaintScene(QObject *parent) :
    QGraphicsScene(parent)
{

    QTimer *m_timer = new QTimer(this);
    //当定时器到设定时间的时候自动执行test()函数
    connect(m_timer, SIGNAL(timeout()), this, SLOT(test()));
    m_timer->start(500);
}

MainPaintScene::~MainPaintScene()
{

}
bool isIncreasing =true;
void MainPaintScene::test()
{
    if(ellipseItem !=nullptr)
    {
        if(isIncreasing)
        {
            pen.setWidth(pen.width()+1);
            if(pen.width()>1)
               isIncreasing=false;
        }
        else
        {
            pen.setWidth(pen.width()-1);
            if(pen.width()<2)
               isIncreasing=true;
        }
        ellipseItem->setPen(pen);
        ellipseItem->setRect(CurrentPos.rx()-0.5*_tWidth,CurrentPos.ry()-0.5*_tWidth,_tWidth,_tWidth);
    }
}


void MainPaintScene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    PrePos =CurrentPos  =event->scenePos();

    addLine(PrePos.rx(),PrePos.ry(),CurrentPos.rx(),CurrentPos.ry(),pen);
    lastTimer =myTimer;

    ellipseItem =new QGraphicsEllipseItem;

    ellipseItem->setPen(pen);
    ellipseItem->setRect(CurrentPos.rx()-0.5*_tWidth,CurrentPos.ry()-0.5*_tWidth,_tWidth,_tWidth);
    addItem(ellipseItem);

}
void MainPaintScene::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    CurrentPos =event->scenePos();

    QGraphicsLineItem *item =new QGraphicsLineItem;
    item->setPen(pen);
    item->setLine(PrePos.rx(),PrePos.ry(),CurrentPos.rx(),CurrentPos.ry());
    addItem(item);
    PrePos =CurrentPos ;
}
void MainPaintScene::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    removeItem(ellipseItem);
    ellipseItem =nullptr;
}
